﻿using System;

namespace valuereferencedemo
{
    class Program
    {

        public static void Methode1(int getal) {
            getal *= 2;
        }

        public static void Methode2(int[] getallen) {
            for(int i = 0; i < getallen.Length; i++) {
                getallen[i] *= 3;
            }
        }

        public static int Methode3(int getal) {
            return 2 * getal;
        }

        public static int Methode4(int getal) {
            return 3 * getal;
        }

        public static void Methode5(string tekst) {
            tekst.ToUpper();
        }

        public static string Methode6(string tekst) {
            return tekst.ToUpper();
        }

        public static void Methode7(int[] getallen) {
            getallen = new int[] {1,1,1};
        }

        public static void Methode8(string[] teksten) {
            teksten[1] = "beste";
        }

        public static void Main()
        {
            int getal = 5;
            Methode1(getal);
            System.Console.WriteLine(getal);

            int[] getallen = {5, 3, 2};
            Methode2(getallen);
            System.Console.WriteLine("Getallen:");
            for(int i = 0; i < getallen.Length; i++) {
                System.Console.WriteLine(getallen[i]);
            }

            Methode3(getal);
            System.Console.WriteLine(getal);

            int resultaat = Methode4(getal);
            System.Console.WriteLine(resultaat);

            string tekst = "tekst";
            Methode5(tekst);
            System.Console.WriteLine(tekst);

            string tekst2 = Methode6(tekst);
            System.Console.WriteLine(tekst2);

            tekst = Methode6(tekst);
            System.Console.WriteLine(tekst);

            Methode7(getallen);
            for(int i = 0; i < getallen.Length; i++) {
                System.Console.WriteLine(getallen[i]);
            }

            string[] teksten = {"hallo", "lieve", "wereld"};
            Methode8(teksten);
            for(int i = 0; i < teksten.Length; i++) {
                System.Console.WriteLine(teksten[i]);
            }
        }
    }
}
