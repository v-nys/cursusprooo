﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    interface IScheduled
    {
        DateTime StartTime
        {
            get;
            set;
        }

        TimeSpan Duration
        {
            get;
            set;
        }

        string CalendarEntry
        {
            get;
            set;
        }
    }
}
