﻿using System;
using System.Collections.Generic;

namespace SchoolAdmin
{
    class Program
    {
        static void Main(string[] args)
        {
            while(true)
            {
                Console.WriteLine("Wat wil je doen?");
                Console.WriteLine("1. DemonstrateStudents uitvoeren");
                Console.WriteLine("2. DemonstrateCourse uitvoeren");
                Console.WriteLine("3. DemonstratePersons uitvoeren");
                Console.WriteLine("4. Personen inlezen uit CSV-file");
                Console.WriteLine("5. Data wegschrijven naar CSV-file");
                int answer = Convert.ToInt32(Console.ReadLine());
                switch (answer)
                {
                    case 1:
                        Student.DemonstrateStudents();
                        break;
                    case 2:
                        Course.DemonstrateCourse();
                        break;
                    case 3:
                        Person.DemonstratePersons();
                        break;
                    case 4:
                        try
                        {
                            Person.ReadFromCsv();
                        }
                        catch (System.IO.FileNotFoundException)
                        {
                            Console.WriteLine("Je bestand Personen.txt ontbreekt of staat op de foute locatie.");
                        }
                        break;
                    case 5:
                        var csvSerializables = new List<ICsvSerializable>();
                        csvSerializables.AddRange(Person.Persons);
                        csvSerializables.AddRange(Course.Courses);
                        foreach(var serializable in csvSerializables)
                        {
                            Console.WriteLine(serializable.ToCsv());
                        }
                        break;
                    default:
                        Console.WriteLine("Ongeldig antwoord.");
                        break;
                }
            }
            

        }
    }
}
