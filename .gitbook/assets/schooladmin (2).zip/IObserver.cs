﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    interface IObserver<T>
    {
        void Observe(T o);
    }
}
