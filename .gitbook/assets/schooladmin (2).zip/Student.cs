﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SchoolAdmin
{
    class Student : Person, IObserver<Course>
    {

        private Dictionary<Course, byte> grades = new Dictionary<Course, byte>();

        public void SetGrade(Course course,byte grade)
        {
            if (grade > 20)
            {
                throw new ArgumentException("cijfer is te hoog!");
            }
            else if (!this.grades.ContainsKey(course))
            {
                this.grades.Add(course, grade);
            }
            else
            {
                this.grades[course] = grade;
            }
        }

        public List<Course> Courses
        {
            get
            {
                return this.grades.Keys.ToList();
            }
        }

        public List<byte> Grades
        {
            get
            {
                return this.grades.Values.ToList();
            }
        }

        public byte LookupGrade(Course course)
        {
            return this.grades[course];
        }

        public double OverallMark
        {
            get
            {
                double total = 0;
                foreach(Course course in this.grades.Keys)
                {
                    total += grades[course];
                }
                return total / grades.Count;
            }
        }

        private static List<Student> students = new List<Student>();
        private List<IScheduled> scheduleds;

        public static List<Student> Students
        {
            get
            {
                return students;
            }
        }

        public override byte WorkHours
        {
            get
            {
                byte total = 0;
                foreach(Course course in this.Courses)
                {
                    total += (byte) (course.StudyPoints * 2);
                }
                return total;
            }
        }

        public Student(string name, byte age) : base(name,age)
        {
            this.scheduleds = new List<IScheduled>();
            Student.Students.Add(this);
        }

        public override string GetOverview()
        {
            string result = $@"{this.Name.ToUpper()}, {this.Age} jaar

Cijferrapport:
**************
";
            foreach(var keyValue in this.grades)
            {
                result += $"{keyValue.Key.Title}: {keyValue.Value}\n";
            }

                result += $"Gemiddelde:               {this.OverallMark:F1}";
                return result;
        }

        public static void DemonstrateStudents()
        {
            Course course1 = new Course("Communicatie", new List<Student>());
            Course course2 = new Course("Programming Principles", new List<Student>());
            Course course3 = new Course("Web Technology", new List<Student>());
            Student student1 = new Student("Joske Vermeulen", 21);
            student1.grades.Add(course1, 15);
            student1.grades.Add(course2, 17);
            student1.grades.Add(course3, 18);
            foreach (Course course in student1.grades.Keys)
            {
                course.Students.Add(student1);
            }
            Student student2 = new Student("Mieke Vermeulen", 20);
            student2.grades.Add(course1, 15);
            student2.grades.Add(course2, 17);
            student2.grades.Add(course3, 18);
            foreach (Course course in student2.grades.Keys)
            {
                course.Students.Add(student2);
            }
            Student student3 = new Student("Mieke Verstrepen", 19);
            student3.grades.Add(course1, 15);
            student3.grades.Add(course2, 17);
            student3.grades.Add(course3, 18);
            foreach (Course course in student3.grades.Keys)
            {
                course.Students.Add(student3);
            }
            Student student4 = new Student("Joske Vercammen", 20);
            student4.grades.Add(course1, 15);
            course1.Students.Add(student4);
            student1.ShowOverview();
            student2.ShowOverview();
            student3.ShowOverview();
            student4.ShowOverview();
        }

        public override string ToCsv()
        {
            return $"Student;{this.Name};{this.Age}";
        }

        public void Observe(Course o)
        {
            Console.WriteLine($"Oh nee, {o.Title} is gewijzigd!");
        }
    }
}
