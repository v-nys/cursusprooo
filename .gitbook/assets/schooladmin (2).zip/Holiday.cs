﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class Holiday : IScheduled
    {
        private DateTime startTime;
        public DateTime StartTime {
            get
            {
                return startTime;
            }
            set
            {
                this.startTime = value;
            }
        }

        private TimeSpan duration;

        public TimeSpan Duration
        {
            get
            {
                return duration;
            }
            set
            {
                this.duration = value;
            }
        }

        private string calendarEntry;
        public string CalendarEntry
        {
            get
            {
                return this.calendarEntry;
            }
            set
            {
                this.calendarEntry = value;
            }
        }

        private string name;
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
    }
}
