﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace SchoolAdmin
{
    class CoursesByStudyPointsComparer : IComparer<Course>
    {
        public int Compare(Course x, Course y)
        {
            return x.StudyPoints.CompareTo(y.StudyPoints);
        }
    }
}
