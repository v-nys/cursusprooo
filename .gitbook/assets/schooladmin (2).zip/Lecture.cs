﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class Lecture : IScheduled
    {
        private DateTime startTime;
        public DateTime StartTime
        {
            get
            {
                return startTime;
            }
            set
            {
                this.startTime = value;
            }
        }

        private TimeSpan duration;

        public TimeSpan Duration
        {
            get
            {
                return duration;
            }
            set
            {
                this.duration = value;
            }
        }

        private string calendarEntry;
        public string CalendarEntry
        {
            get
            {
                return this.calendarEntry;
            }
            set
            {
                this.calendarEntry = value;
            }
        }

        private Course associatedCourse;
        public Course AssociatedCourse
        {
            get
            {
                return this.associatedCourse;
            }
            set
            {
                this.associatedCourse = value;
            }
        }

        private Lecturer lecturer;
        public Lecturer Lecturer
        {
            get
            {
                return this.lecturer;
            }
            set
            {
                this.lecturer = value;
            }
        }
    }
}
