﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace SchoolAdmin
{
    class LecturersByAgeComparer : IComparer<Lecturer>
    {
        public int Compare(Lecturer x, Lecturer y)
        {
            return x.Age.CompareTo(y.Age);
        }
    }
}
