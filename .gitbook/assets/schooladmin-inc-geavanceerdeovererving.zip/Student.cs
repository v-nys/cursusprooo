﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Text;

namespace SchoolAdmin
{
    class Student : Persoon
    {

        public static ImmutableList<Student> AlleStudenten
        {
            get
            {
                var enkelStudenten = new List<Student>();
                foreach (var persoon in Persoon.AllePersonen)
                {
                    if (persoon is Student)
                    {
                        enkelStudenten.Add((Student)persoon);
                    }
                }
                return enkelStudenten.ToImmutableList<Student>();
            }
        }

        public ImmutableList<VakInschrijving> VakInschrijvingen
        {
            get
            {
                var enkelVoorDezeStudent = new List<VakInschrijving>();
                foreach (var inschrijving in VakInschrijving.AlleVakInschrijvingen)
                {
                    if (inschrijving.Student.Equals(this))
                    {
                        enkelVoorDezeStudent.Add(inschrijving);
                    }
                }
                return enkelVoorDezeStudent.ToImmutableList<VakInschrijving>();
            }
        }

        public ImmutableList<Cursus> Cursussen
        {
            get
            {
                var cursussen = new List<Cursus>();
                foreach (var inschrijving in this.VakInschrijvingen)
                {
                    cursussen.Add(inschrijving.Cursus);
                }
                return cursussen.ToImmutableList<Cursus>();
            }
        }

        private Dictionary<DateTime,string> dossier;
        public ImmutableDictionary<DateTime,string> Dossier {
            get {
                return this.dossier.ToImmutableDictionary<DateTime,string>();
            }
        }

        public Student(string naam, DateTime geboorteDatum) : base(naam, geboorteDatum)
        {
            this.dossier = new Dictionary<DateTime, string>();
        }

        public override string GenereerNaamkaartje()
        {
            return $"{this.Naam} (STUDENT)";
        }

        public override double BepaalWerkbelasting()
        {
            double totaal = 0.0;
            foreach(var inschrijving in this.VakInschrijvingen) {
                totaal += 10;
            }
            return totaal;
        }

        public double Gemiddelde()
        {
            int aantalCijfers = 0;
            double totaal = 0;
            foreach(var inschrijving in this.VakInschrijvingen) {
                if (!(inschrijving.Resultaat is null))
                    {
                        totaal += (byte) inschrijving.Resultaat;
                        aantalCijfers++;
                    }
            }
            return totaal / aantalCijfers;
        }

        public void Kwoteer(byte cursusIndex, byte behaaldCijfer)
        {
            if (cursusIndex < 0 || cursusIndex >= VakInschrijvingen.Count || VakInschrijvingen[cursusIndex] is null || behaaldCijfer > 20)
            {
                Console.WriteLine("Ongeldig cijfer!");
            }
            else
            {
                VakInschrijvingen[cursusIndex].Resultaat = behaaldCijfer;
            }
        }

        public void RegistreerCursusResultaat(Cursus cursus, byte? resultaat)
        {
            new VakInschrijving(this, cursus, resultaat);
        }

        public void ToonOverzicht()
        {
            DateTime nu = DateTime.Now;
            int aantalJaar = nu.Year - this.Geboortedatum.Year - 1;
            if (nu.Month > this.Geboortedatum.Month || nu.Month == this.Geboortedatum.Month && nu.Day >= this.Geboortedatum.Day)
            {
                aantalJaar++;
            }
            Console.WriteLine($"{this.Naam}, {aantalJaar} jaar");
            Console.WriteLine();
            Console.WriteLine("Cijferrapport");
            Console.WriteLine("**********");
            foreach(var inschrijving in this.VakInschrijvingen) {
                if (!(inschrijving is null))
                {
                    Console.WriteLine($"{inschrijving.Cursus.Titel}:\t{inschrijving.Resultaat}");
                }
            }
            Console.WriteLine($"Gemiddelde:\t{this.Gemiddelde()}\n");
        }

        public override string ToString()
        {
            return $"{base.ToString()}\nMeerbepaald, een student";
        }

        public static Student StudentUitTekstformaat(string csvWaarde)
        {
            string[] gegevens = csvWaarde.Split(";");
            int dag = Convert.ToInt32(gegevens[1]);
            int maand = Convert.ToInt32(gegevens[2]);
            int jaar = Convert.ToInt32(gegevens[3]);
            Student student = new Student(gegevens[0], new DateTime(jaar, maand, dag));
            for(int volgendeIndex = 4; volgendeIndex < gegevens.Length; volgendeIndex += 2)
            {
                int vakId = Convert.ToInt32(gegevens[volgendeIndex]);
                Cursus vak = Cursus.ZoekCursusOpId(vakId);
                if (!(vak is null))
                {
                    byte resultaat = Convert.ToByte(gegevens[volgendeIndex + 1]);
                    student.RegistreerCursusResultaat(vak, resultaat);
                }
            }
            return student;
        }

        public static void DemonstreerStudentUitTekstFormaat()
        {
            Cursus communicatie = new Cursus("Communicatie");
            Cursus programmeren = new Cursus("Programmeren");
            Cursus webtechnologie = new Cursus("Webtechnologie",  6);
            Cursus databanken = new Cursus("Databanken", 5);
            string csv = Console.ReadLine();
            Student student = Student.StudentUitTekstformaat(csv);
            student.ToonOverzicht();
        }

        public static void DemonstreerStudenten()
        {
            Cursus communicatie = new Cursus("Communicatie");
            Cursus programmeren = new Cursus("Programmeren");
            Cursus webtechnologie = new Cursus("Webtechnologie", 6);
            Cursus databanken = new Cursus("Databanken", 5);

            Student student1 = new Student("Said Aziz", new DateTime(2001, 1, 3));
            student1.RegistreerCursusResultaat(communicatie,12);
            student1.RegistreerCursusResultaat(programmeren, 15);
            student1.RegistreerCursusResultaat(webtechnologie, 13);
            student1.ToonOverzicht();

            Student student2 = new Student("Mieke Vermeulen", new DateTime(2000, 2, 1));
            student2.RegistreerCursusResultaat(communicatie, 13);
            student2.RegistreerCursusResultaat(programmeren, 16);
            student2.RegistreerCursusResultaat(databanken, 14);
            student2.ToonOverzicht();
        }

        public static void LeesVanafCommandLine()
        {
            Console.WriteLine("Naam van de student?");
            var naam = Console.ReadLine();
            Console.WriteLine("Geboortedatum van de student?");
            var geboorteDatum = Convert.ToDateTime(Console.ReadLine());
            new Student(naam, geboorteDatum);
        }
    }
}
