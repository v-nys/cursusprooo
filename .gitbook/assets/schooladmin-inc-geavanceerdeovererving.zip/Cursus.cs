﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Text;

namespace SchoolAdmin
{
    class Cursus
    {
        public string Titel;

        private static int maxId = 1;
        private static List<Cursus> alleCursussen = new List<Cursus>();
        public static ImmutableList<Cursus> AlleCursussen {
            get {
                return alleCursussen.ToImmutableList<Cursus>();
            }
        }

        private int id;
        public int Id
        {
            get
            {
                return this.id;
            }
        }

        private byte studiepunten;
        public byte Studiepunten
        {
            get
            {
                return this.studiepunten;
            }
            private set
            {
                this.studiepunten = value;
            }
        }

        public ImmutableList<VakInschrijving> VakInschrijvingen
        {
            get
            {
                var enkelVoorDezeCursus = new List<VakInschrijving>();
                foreach (var inschrijving in VakInschrijving.AlleVakInschrijvingen)
                {
                    if (inschrijving.Cursus.Equals(this))
                    {
                        enkelVoorDezeCursus.Add(inschrijving);
                    }
                }
                return enkelVoorDezeCursus.ToImmutableList<VakInschrijving>();
            }
        }

        public ImmutableList<Student> Studenten
        {
            get
            {
                var studenten = new List<Student>();
                foreach (var inschrijving in this.VakInschrijvingen)
                {
                    studenten.Add(inschrijving.Student);
                }
                return studenten.ToImmutableList<Student>();
            }
        }

        public Cursus(string titel, byte studiepunten)
        {
            this.Titel = titel;
            this.id = Cursus.maxId;
            this.Studiepunten = studiepunten;
            Cursus.maxId++;
            registreerCursus(this);
        }

        public Cursus(string titel) : this(titel, 3)
        {
        }

        public void ToonOverzicht()
        {
            string uitvoer = $"{this.Titel} ({this.Id}) ({this.Studiepunten} stp)\n";
            foreach (var student in Studenten)
            {
                if (!(Studenten is null))
                {
                    uitvoer += $"{student.Naam}\n";
                }
            }
            Console.WriteLine(uitvoer);
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }
            if (obj is Cursus)
            {
                var objCursus = (Cursus) obj;
                return objCursus.Id == this.Id;
            }
            else
            {
                return false;
            }
        }

        public override int GetHashCode()
        {
            return this.Id.GetHashCode();
        }

        public static void LeesVanafCommandLine()
        {
            Console.WriteLine("Titel van de cursus?");
            var titel = Console.ReadLine();
            Console.WriteLine("Aantal studiepunten?");
            byte aantal = Convert.ToByte(Console.ReadLine());
            new Cursus(titel, aantal);
        }

        public static void DemonstreerCursussen()
        {
            Cursus communicatie = new Cursus("Communicatie");
            Cursus programmeren = new Cursus("Programmeren");
            Cursus webtechnologie = new Cursus("Webtechnologie",  6);
            Cursus databanken = new Cursus("Databanken", 5);

            Student student1 = new Student("Said Aziz", new DateTime(2001, 1, 3));
            student1.RegistreerCursusResultaat(communicatie, 12);
            student1.RegistreerCursusResultaat(programmeren, null);
            student1.RegistreerCursusResultaat(webtechnologie, 13);
            student1.ToonOverzicht();

            Student student2 = new Student("Mieke Vermeulen", new DateTime(2000, 2, 1));
            student2.RegistreerCursusResultaat(communicatie, 13);
            student2.RegistreerCursusResultaat(programmeren, null);
            student2.RegistreerCursusResultaat(databanken, 14);
            student2.ToonOverzicht();

            communicatie.ToonOverzicht();
            programmeren.ToonOverzicht();
            webtechnologie.ToonOverzicht();
            databanken.ToonOverzicht();

        }

        private static void registreerCursus(Cursus cursus)
        {
            alleCursussen.Add(cursus);
        }

        public static Cursus ZoekCursusOpId(int id)
        {
            foreach(Cursus cursus in AlleCursussen)
            {
                if (cursus.Id == id)
                {
                    return cursus;
                }
            }
            return null;
        }
    }
}
