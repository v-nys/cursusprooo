﻿using System;

namespace valuereferencedemo
{
    class Program
    {
        public static string Methode1(int getal1, bool waarheid) {
            int getal2 = 3;
            if (waarheid) {
                return $"Drie keer je getal is {getal2 * getal1}";
            }
            else {
                return $"Drie keer je getal is {getal2 * getal1 - 1}";
            }
        }

        public static void Methode3(int getal, bool waarheid,
                                    string tekst, int[] getallen,
                                    string[] tekstjes) {
            tekst = "Abracadabra!";
            waarheid = !waarheid;
            for(int i = 0; i < getallen.Length; i++) {
                getallen[i] *= getal;
            }
            for(int i = 0; i < tekstjes.Length; i++) {
                tekstjes[i] = tekstjes[i].ToUpper();
            }
        }

        public static void Methode2() {
            int getal = 17;
            bool waarheid = false;
            string tekst = "Tingle tingle koolooh limpah!";
            int[] getallen = {4, 7, 2, 3};
            string[] tekstjes = {"It's dangerous to go alone! Take this.",
                                 "It's a-me, Mario!",
                                 "Do a barrel roll!"};
            Methode3(getal,waarheid,tekst,getallen,tekstjes);
            // debug en teken tot je onderstaande resultaten begrijpt!
            for(int i = 0; i < getallen.Length; i++) {
                System.Console.WriteLine(getallen[i]);
            }
            System.Console.WriteLine(tekst);
            for(int i = 0; i < tekstjes.Length; i++) {
                System.Console.WriteLine(tekstjes[i]);
            }
        }

        public static void Main()
        {
            int getal = 32;
            bool waarheid = true;
            Console.WriteLine(Methode1(getal,waarheid));
            // zelfs als Methode1 getal en waarheid zou aanpassen zouden deze nu 32/true zijn
            Methode2();
        }
    }
}
