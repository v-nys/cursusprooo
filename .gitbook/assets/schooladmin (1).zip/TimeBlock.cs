﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class TimeBlock
    {

        private byte startHour;
        public byte StartHour
        {
            get
            {
                return this.startHour;
            }
        }

        private byte startMinute;
        public byte StartMinute
        {
            get
            {
                return this.startMinute;
            }
        }

        private byte endHour;
        public byte EndHour
        {
            get
            {
                return this.endHour;
            }
        }


        private byte endMinute;
        public byte EndMinute
        {
            get
            {
                return this.endMinute;
            }
        }

        public TimeBlock(byte startHour, byte startMinute, byte endHour, byte endMinute)
        {
            int startAsMinutes = startHour * 60 + startMinute;
            int endAsMinutes = endHour * 60 + endMinute;
            if (startAsMinutes >= endAsMinutes)
            {
                throw new ArgumentException("Het begintijdstip mag niet voor het eindtijdstip liggen.");
            }
            if (startHour >= 24 || endHour >= 24)
            {
                throw new ArgumentException("Uur ligt boven 24");
            }
            if (startMinute >= 60 || endMinute >= 60)
            {
                throw new ArgumentException("Minuut ligt boven 60");
            }
            this.startHour = startHour;
            this.startMinute = startMinute;
            this.endHour = endHour;
            this.endMinute = endMinute;
        }
    }
}
