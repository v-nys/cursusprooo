﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class AdministrativeStaff : Person
    {
        private Dictionary<string, byte> tasks;

        public Dictionary<string,byte> Tasks
        {
            get
            {
                return this.tasks;
            }
            private set
            {
                this.tasks = value;
            }
        }

        public AdministrativeStaff(string name, byte age) : base(name,age)
        {
            this.Tasks = new Dictionary<string, byte>();
        }

        public override byte WorkHours
        {
            get
            {
                byte total = 0;
                foreach (var hours in this.Tasks.Values)
                {
                    total += hours;
                }
                return total;
            }
        }

        public override string GetOverview()
        {
            string overview = this.Name;
            foreach (var task in this.Tasks)
            {
                overview += $"\n{task.Key}: {task.Value}";
            }
            overview += $"\n{this.WorkHours}";
            return overview;
        }
    }
}
