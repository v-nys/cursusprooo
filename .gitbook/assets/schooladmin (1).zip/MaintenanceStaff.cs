﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class MaintenanceStaff : Person
    {
        public override byte WorkHours
        {
            get
            {
                int totalMinutes = 0;
                foreach (DayOfWeek item in this.Schedule.Keys)
                {
                    TimeBlock today = this.Schedule[item];
                    int endMinutes = today.EndHour * 60 + today.EndMinute;
                    int startMinutes = today.StartHour * 60 + today.StartMinute;
                    totalMinutes += (endMinutes - startMinutes);
                }
                return (byte)(totalMinutes / 60);
            }
        }

        private Dictionary<DayOfWeek, TimeBlock> schedule;
        public Dictionary<DayOfWeek, TimeBlock> Schedule {
            get
            {
                return schedule;
            }
        }

        private List<string> responsibilities;
        public List<string> Responsibilities
        {
            get
            {
                return responsibilities;
            }
        }

        private static List<MaintenanceStaff> maintenance = new List<MaintenanceStaff>();

        public MaintenanceStaff(string name, byte age) : base(name, age)
        {
            this.schedule = new Dictionary<DayOfWeek, TimeBlock>();
            this.responsibilities = new List<string>();
            maintenance.Add(this);
        }

        public void SetWorkBlock(DayOfWeek day, TimeBlock block)
        {
            this.Schedule[day] = block;
        }

        public void AddResponsibility(string responsibility)
        {
            this.Responsibilities.Add(responsibility);
        }

        public override string GetOverview()
        {
            string result = $"{this.Name} (onderhoud)\nVerantwoordelijkheden:\n";
            foreach(string responsibility in this.Responsibilities)
            {
                result += responsibility + "\n";
            }
            result += "Schema:\n";
            foreach(var item in this.Schedule)
            {
                string line = $"{item.Key}: {item.Value.StartHour:D2}:{item.Value.StartMinute:D2} tot {item.Value.EndHour:D2}:{item.Value.EndMinute:D2}";
                if (DateTime.Now.DayOfWeek == item.Key)
                {
                    result += $"***{line}***\n";
                }
                else
                {
                    result += line + "\n";
                }
            }
            return result;
        }

        public static void ShowAll()
        {
            Console.WriteLine(maintenance.Count);
            int working = 0;
            foreach(MaintenanceStaff staff in maintenance)
            {
                if (staff.Schedule.ContainsKey(DateTime.Now.DayOfWeek))
                {
                    working++;
                }
            }
            Console.WriteLine(working);
            foreach(MaintenanceStaff staff in maintenance)
            {
                staff.ShowOverview();
            }
        }
    }
}
