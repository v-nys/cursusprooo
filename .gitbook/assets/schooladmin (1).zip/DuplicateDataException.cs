﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class DuplicateDataException : ApplicationException
    {
        public DuplicateDataException(string message) : base(message)
        {

        }
    }
}
