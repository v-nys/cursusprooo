﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin
{
    class StudyProgram
    {
        private string name;

        public string Name
        {
            get { return name; }
            set {
                if (name == "" || value is null)
                {
                    throw new ArgumentException("Naam mag niet leeg zijn!");
                }
                else
                {
                    this.name = value;
                }
            }
        }

        private List<Course> courses;

        public List<Course> Courses
        {
            get { return courses; }
            set {
                if (value is null)
                {
                    throw new ArgumentException("Er moeten cursussen in een studieprogramma bijgehouden kunnen worden.");
                }
                courses = value;
            }
        }

        public int TotalStudyPoints
        {
            get
            {
                int total = 0;
                foreach (Course course in this.courses)
                {
                    total += course.StudyPoints;
                }
                return total;
            }
        }

        public StudyProgram(string name, List<Course> courses)
        {
            this.Name = name;
            this.Courses = courses;
        }

        public StudyProgram(string name) : this(name,new List<Course>())
        {

        }

        public string GetOverview()
        {
            var lines = new List<string>();
            lines.Add(this.Name.ToUpper());
            foreach(Course course in this.Courses)
            {
                lines.Add($"{course.Title}: {course.StudyPoints} studiepunten");
            }
            lines.Add($"Totaal: {this.TotalStudyPoints} studiepunten");
            return String.Join("\n", lines);
        }

        public void ShowOverview()
        {
            Console.WriteLine(this.GetOverview());
        }

        public void RegisterCourse(Course course)
        {
            if (!(course is null)) {
                this.Courses.Add(course);
            }
        }

        // later op terugkomen na datastructuren en/of vergelijken van objectreferenties
        public List<Student> Students
        {
            get
            {
                var students = new List<Student>();
                foreach (Course course in this.Courses)
                {
                        foreach (Student student in course.Students)
                        {
                            if (!students.Contains(student))
                            {
                                students.Add(student);
                            }
                        }
                }
                return students;
            }
        }

        public List<byte> Grades
        {
            get
            {
                var grades = new List<byte>();
                foreach(Student student in this.Students)
                {
                    foreach(byte grade in student.Grades)
                    {
                        grades.Add(grade);
                    }
                }
                return grades;
            }
        }

        public List<byte> CompactGrades
        {
            get
            {
                var grades = this.Grades;
                for(int i = 0; i < grades.Count; i++)
                {
                    grades[i] = (byte) (grades[i] / 4);
                }
                return grades;
            }
        }

        public void ApplyBonusCredit()
        {
            foreach (Student student in this.Students)
            {
                foreach(Course course in student.Courses)
                {
                    if (student.LookupGrade(course) < 20)
                    {
                        student.SetGrade(course, (byte) (student.LookupGrade(course) + 1));
                    }
                }
            }
        }

    }
}
