﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SchoolAdmin
{
    class Course
    {
        private string title;

        public string Title
        {
            get { return title; }
            set {
                if(value == "" || value is null)
                {
                    throw new ArgumentException("De titel van een vak mag niet leeg zijn.");
                }
                title = value;
            }
        }

        private List<Student> students = new List<Student>();

        public List<Student> Students
        {
            get { return students; }
            private set
            {
                if (value is null)
                {
                    throw new ArgumentException("Een lege rij studenten is niet toegestaan.");
                }
                this.students = value;
            }
        }

        public void ShowOverview()
        {
            Console.WriteLine(this.GetOverview());
        }

        public string GetOverview()
        {
            var items = new List<string>();
            items.Add(this.Title.ToUpper());
            foreach(Student student in this.Students)
            {
                items.Add(student.Name);
            }
            return String.Join("\n", items);
        }

        private byte studyPoints;

        public byte StudyPoints
        {
            get { return studyPoints; }
            set
            {
                if (value < 1 || value > 30)
                {
                    throw new ArgumentException("Ongeldig aantal studiepunten");
                }
                this.studyPoints = value;
            }
        }

        private static List<Course> courses = new List<Course>();

        public static List<Course> Courses
        {
            get
            {
                return courses;
            }
        }

        public Course(string title, List<Student> students, byte studyPoints)
        {
            this.Title = title;
            this.Students = students;
            this.StudyPoints = studyPoints;
            if (Course.Courses.Contains(this))
            {
                throw new DuplicateDataException("Er is al een identieke cursus aanwezig in het systeem.");
            }
            Course.Courses.Add(this);
        }

        public Course(string title, List<Student> students) : this(title, students, 3)
        {
        }


        public static void DemonstrateCourse()
        {
            Course course1 = new Course("Communicatie", new List<Student>());
            Course course2 = new Course("Programming Principles", new List<Student>());
            Course course3 = new Course("Web Technology", new List<Student>());
            Student student1 = new Student("Joske Vermeulen", 21);
            student1.SetGrade(course1, 15);
            student1.SetGrade(course2, 17);
            student1.SetGrade(course3, 18);
            foreach(Course course in student1.Courses)
            {
                course.Students.Add(student1);
            }
            Student student2 = new Student("Mieke Vermeulen", 20);
            student2.SetGrade(course1, 15);
            student2.SetGrade(course2, 17);
            student2.SetGrade(course3, 18);
            foreach (Course course in student2.Courses)
            {
                course.Students.Add(student2);
            }
            Student student3 = new Student("Mieke Verstrepen", 19);
            student3.SetGrade(course1, 15);
            student3.SetGrade(course2, 17);
            student3.SetGrade(course3, 18);
            foreach (Course course in student3.Courses)
            {
                course.Students.Add(student3);
            }
            Student student4 = new Student("Joske Vercammen", 20);
            student4.SetGrade(course1, 15);
            course1.Students.Add(student4);
            course1.ShowOverview();
            course2.ShowOverview();
            course3.ShowOverview();
            
        }

        public static void ReadFromCsv()
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Vincent Nys\Documents\Cursussen.txt");
            foreach (string line in lines)
            {
                try
                {
                    string[] elements = line.Split(';');
                    Course course = new Course(elements[0], new List<Student>(), Convert.ToByte(elements[1]));
                }
                catch (DuplicateDataException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (FormatException e)
                {
                    Console.WriteLine($"Kon een onderdeel van regel {line} niet parsen");
                }
                catch (IndexOutOfRangeException e)
                {
                    Console.WriteLine($"Regel {line} bevat niet het verwachte aantal elementen voor dit type data");
                }
                catch (ArgumentException)
                {
                    Console.WriteLine($"Regel {line} bevat ongeldige data");
                }
            }
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }
            else if (this.GetType() != obj.GetType())
            {
                return false;
            }
            else
            {
                Course objCourse = (Course)obj;
                return this.Title == objCourse.Title && this.StudyPoints == objCourse.StudyPoints;
            }
        }

    }
}
