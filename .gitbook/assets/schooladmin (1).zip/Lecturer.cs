﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Schema;

namespace SchoolAdmin
{
    class Lecturer : Person
    {

        private static List<Lecturer> lecturers = new List<Lecturer>();

        private Dictionary<Course,byte> workload;

        public Dictionary<Course,byte> Workload
        {
            get { return workload; }
        }


        public static List<Lecturer> Lecturers
        {
            get
            {
                return lecturers;
            }
        }

        public override byte WorkHours
        {
            get
            {
                double total = 0;
                foreach(byte hours in this.Workload.Values)
                {
                    total += hours * 2.5;
                }
                return (byte)Math.Round(total);
            }
        }

        public Lecturer(string name, byte age) : base(name, age)
        {
            this.workload = new Dictionary<Course, byte>();
            Lecturer.Lecturers.Add(this);
        }

        public override string GetOverview()
        {
            string result = $@"{this.Name.ToUpper()}, {this.Age} jaar";
            foreach(Course course in this.Workload.Keys)
            {
                result += $"Cursus {course.Title}: {this.Workload[course]} uren per week";
            }
            return result;
        }

    }
}
