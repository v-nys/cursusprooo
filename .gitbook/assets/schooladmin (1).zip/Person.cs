﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace SchoolAdmin
{
    abstract class Person
    {
        private byte age;

        public byte Age
        {
            get { return age; }
            set {
                if(value > 120)
                {
                    throw new ArgumentException("Leeftijd is te hoog.");
                }
                age = value;
            }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set {
                if (value is null || value == "")
                {
                    throw new ArgumentException("Naam mag niet ontbreken!");
                }
                name = value; }
        }

        public abstract byte WorkHours
        {
            get;
        }

        private static List<Person> persons = new List<Person>();


        public static List<Person> Persons
        {
            get
            {
                return persons;
            }
        }

        public static void ReadFromCsv()
        {
            string[] lines = File.ReadAllLines(@"C:\Users\Vincent Nys\Documents\Personen.txt");
            foreach (string line in lines)
            {
                try
                {
                    string[] elements = line.Split(';');
                    Person person = null;
                    switch (elements[0])
                    {
                        case "AdministrativeStaff":
                            person = new AdministrativeStaff(elements[1], Convert.ToByte(elements[2]));
                            break;
                        case "Lecturer":
                            person = new Lecturer(elements[1], Convert.ToByte(elements[2]));
                            break;
                        case "Student":
                            person = new Student(elements[1], Convert.ToByte(elements[2]));
                            break;
                        case "MaintenanceStaff":
                            person = new MaintenanceStaff(elements[1], Convert.ToByte(elements[2]));
                            break;
                        default:
                            Console.WriteLine($"De klasse {elements[0]} wordt niet ondersteund.");
                            break;
                    }
                }
                catch (DuplicateDataException e)
                {
                    Console.WriteLine(e.Message);
                }
                catch (FormatException e)
                {
                    Console.WriteLine($"Kon een onderdeel van regel {line} niet parsen");
                }
                catch (IndexOutOfRangeException e)
                {
                    Console.WriteLine($"Regel {line} bevat niet het verwachte aantal elementen voor dit type data");
                }
                catch (ArgumentException)
                {
                    Console.WriteLine($"Regel {line} bevat ongeldige data");
                }
            }
        }

        public Person(string name, byte age)
        {
            this.Name = name;
            this.Age = age;
            if (Persons.Contains(this))
            {
                throw new DuplicateDataException("persoon was al aanwezig in de lijst met personen");
            }
            Person.Persons.Add(this);
        }

        public void ShowOverview()
        {
            Console.WriteLine(this.GetOverview());
        }

        public abstract string GetOverview();

        public static void DemonstratePersons()
        {
            Course course1 = new Course("Communicatie", new List<Student>());
            Course course2 = new Course("Programming Principles", new List<Student>());
            Course course3 = new Course("Web Technology", new List<Student>());
            Student student1 = new Student("Joske Vermeulen", 21);
            student1.SetGrade(course1, 15);
            student1.SetGrade(course2, 17);
            student1.SetGrade(course3, 18);
            foreach (Course course in student1.Courses)
            {
                course.Students.Add(student1);
            }
            Lecturer lecturer1 = new Lecturer("Adem Kaya", 44);
            lecturer1.Workload[course2] = 9;
            AdministrativeStaff administrativeStaff1 = new AdministrativeStaff("Dimitro Kononenko", 42);
            administrativeStaff1.Tasks["administratie"] = 22;
            administrativeStaff1.Tasks["PR"] = 9;
            administrativeStaff1.Tasks["studentenbegeleiding"] = 7;

            foreach(Person person in Person.Persons)
            {
                person.ShowOverview();
                Console.WriteLine($"Deze persoon heeft {person.WorkHours} uren werk per week.");
            }
        }

        public override bool Equals(object obj)
        {
            if (obj is null)
            {
                return false;
            }
            else if (this.GetType() != obj.GetType())
            {
                return false;
            }
            else
            {
                Person objPerson = (Person) obj;
                return this.Name == objPerson.Name && this.Age == objPerson.Age;
            }
        }

    }
}
